import React from 'react'

function Beauty1() {
  return (
    <div>Beauty1</div>
  )
}

export default Beauty1