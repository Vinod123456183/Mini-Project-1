import React from 'react'

function Beauty3() {
  return (
    <div>Beauty3</div>
  )
}

export default Beauty3