import React from 'react'

function Beauty2() {
  return (
    <div>Beauty2</div>
  )
}

export default Beauty2