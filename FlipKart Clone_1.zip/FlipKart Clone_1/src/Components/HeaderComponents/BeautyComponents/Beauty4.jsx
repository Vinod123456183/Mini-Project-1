import React from 'react'

function Beauty4() {
  return (
    <div>Beauty4</div>
  )
}

export default Beauty4