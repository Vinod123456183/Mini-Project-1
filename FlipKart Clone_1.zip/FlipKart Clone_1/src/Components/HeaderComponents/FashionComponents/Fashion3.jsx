import React from 'react'

function Fashion3() {
  return (
    <div>Fashion3</div>
  )
}

export default Fashion3