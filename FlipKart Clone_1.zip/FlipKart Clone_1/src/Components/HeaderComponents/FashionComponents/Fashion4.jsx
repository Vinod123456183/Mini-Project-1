import React from 'react'

function Fashion4() {
  return (
    <div>Fashion4</div>
  )
}

export default Fashion4