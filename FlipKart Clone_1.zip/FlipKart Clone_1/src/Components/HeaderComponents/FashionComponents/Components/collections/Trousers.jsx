import React from 'react'

function Trousers() {
  return (
    <div>Trousers</div>
  )
}

export default Trousers