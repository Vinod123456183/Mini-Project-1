import React from 'react'

function Denims() {
  return (
    <div>Denims</div>
  )
}

export default Denims