import React from 'react'

function Jeans() {
  return (
    <div>Jeans</div>
  )
}

export default Jeans