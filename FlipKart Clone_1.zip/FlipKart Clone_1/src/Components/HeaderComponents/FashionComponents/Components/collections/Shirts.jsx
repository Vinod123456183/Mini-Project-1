import React from 'react'

function Shirts() {
  return (
    <div>Shirts</div>
  )
}

export default Shirts