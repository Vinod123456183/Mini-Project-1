import React from 'react'

function Sweater() {
  return (
    <div>Sweater</div>
  )
}

export default Sweater