import React from "react";

function Newdrops() {
  return <div>Newdrops</div>;
}

export default Newdrops;
