import React from 'react'

function Electronics2() {
  return (
    <div>Electronics2</div>
  )
}

export default Electronics2