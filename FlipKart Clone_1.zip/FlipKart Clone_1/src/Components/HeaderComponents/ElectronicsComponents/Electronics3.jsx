import React from 'react'

function Electronics3() {
  return (
    <div>Electronics3</div>
  )
}

export default Electronics3