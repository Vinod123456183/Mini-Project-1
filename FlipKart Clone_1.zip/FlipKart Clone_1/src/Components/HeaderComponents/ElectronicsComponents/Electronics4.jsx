import React from 'react'

function Electronics4() {
  return (
    <div>Electronics4</div>
  )
}

export default Electronics4