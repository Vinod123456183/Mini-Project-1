import React from 'react'

function Electronics1() {
  return (
    <div>Electronics1</div>
  )
}

export default Electronics1