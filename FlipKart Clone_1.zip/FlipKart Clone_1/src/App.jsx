import { Outlet } from "react-router-dom";
import Fashion from "./Components/HeaderComponents/FashionComponents/Fashion1";
import './App.css'
function App() {
  return (
    <>
      <Outlet />
    </>
  );
}

export default App;
