import React from "react";
import Hoodies from "./BestSeller/Hoodies";
function BestOffers() {
  return (
    <div>
      <div className="grid grid-cols-4 ">
        <Hoodies
          img={
            "https://imgs.search.brave.com/5dRuBOedlVFn8yCv2UHpQiDQ5CZoQUDGb1h6x3FfpTA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90My5m/dGNkbi5uZXQvanBn/LzAzLzg4LzA3Lzg0/LzM2MF9GXzM4ODA3/ODQ1NF9tS3RiZFhZ/RjljeVFvdkNDVHNq/cUkwZ2JmdTdnQ2NT/cC5qcGc"
          }
          name={"names"}
          price={"prcies"}
          onClick={() => {
            console.error("es");
          }}
        />
        <Hoodies
          img={
            "https://imgs.search.brave.com/5dRuBOedlVFn8yCv2UHpQiDQ5CZoQUDGb1h6x3FfpTA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90My5m/dGNkbi5uZXQvanBn/LzAzLzg4LzA3Lzg0/LzM2MF9GXzM4ODA3/ODQ1NF9tS3RiZFhZ/RjljeVFvdkNDVHNq/cUkwZ2JmdTdnQ2NT/cC5qcGc"
          }
          name={"names"}
          price={"prcies"}
          onClick={() => {
            console.error("es");
          }}
        />
        <Hoodies
          img={
            "https://imgs.search.brave.com/5dRuBOedlVFn8yCv2UHpQiDQ5CZoQUDGb1h6x3FfpTA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90My5m/dGNkbi5uZXQvanBn/LzAzLzg4LzA3Lzg0/LzM2MF9GXzM4ODA3/ODQ1NF9tS3RiZFhZ/RjljeVFvdkNDVHNq/cUkwZ2JmdTdnQ2NT/cC5qcGc"
          }
          name={"names"}
          price={"prcies"}
          onClick={() => {
            console.error("es");
          }}
        />
        <Hoodies
          img={
            "https://imgs.search.brave.com/5dRuBOedlVFn8yCv2UHpQiDQ5CZoQUDGb1h6x3FfpTA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90My5m/dGNkbi5uZXQvanBn/LzAzLzg4LzA3Lzg0/LzM2MF9GXzM4ODA3/ODQ1NF9tS3RiZFhZ/RjljeVFvdkNDVHNq/cUkwZ2JmdTdnQ2NT/cC5qcGc"
          }
          name={"names"}
          price={"prcies"}
          onClick={() => {
            console.error("es");
          }}
        />
        <Hoodies
          img={
            "https://imgs.search.brave.com/5dRuBOedlVFn8yCv2UHpQiDQ5CZoQUDGb1h6x3FfpTA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90My5m/dGNkbi5uZXQvanBn/LzAzLzg4LzA3Lzg0/LzM2MF9GXzM4ODA3/ODQ1NF9tS3RiZFhZ/RjljeVFvdkNDVHNq/cUkwZ2JmdTdnQ2NT/cC5qcGc"
          }
          name={"names"}
          price={"prcies"}
          onClick={() => {
            console.error("es");
          }}
        />{" "}
      </div>
    </div>
  );
}

export default BestOffers;
